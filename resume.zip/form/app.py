
from flask import Flask, render_template, request
import os
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/details')
def details():
    return render_template('details.html')

@app.route('/submit', methods=['POST'])
def submit():
    #data = request.form.to_dict()
    #template = data.pop('template')  # Get the selected template and remove it from the data dictionary
    #return render_template(template, data=data)
    data = request.form.to_dict(flat=False)
    
    # Extract the data from the form
    form_data = {
        'yourname': data.get('yourname', [''])[0],
        'youremail': data.get('youremail', [''])[0],
        'contact': data.get('contact', [''])[0],
        'fathername': data.get('fathername', [''])[0],
        'address': data.get('address', [''])[0],
        'residance': data.get('residance', [''])[0],
        'dob': data.get('dob', [''])[0],
        'lang': data.get('lang', [''])[0],
        'gb': data.get('gb', [''])[0],
        'gs': data.get('gs', [''])[0],
        'gp': data.get('gp', [''])[0],
        'gm': data.get('gm', [''])[0],
        'tb': data.get('tb', [''])[0],
        'ts': data.get('ts', [''])[0],
        'tp': data.get('tp', [''])[0],
        'tm': data.get('tm', [''])[0],
        'tvb': data.get('tvb', [''])[0],
        'tvs': data.get('tvs', [''])[0],
        'tvp': data.get('tvp', [''])[0],
        'tvm': data.get('tvm', [''])[0],
        'about': data.get('about', [''])[0],
        'template': data.get('template', [''])[0],
    }
    
    # Extract experiences, projects, skills, and achievements
    form_data['experiences'] = [
        {'company': company, 'role': role, 'duration': duration, 'responsibilities': responsibilities}
        for company, role, duration, responsibilities in zip(
            data.get('company[]', []),
            data.get('role[]', []),
            data.get('duration[]', []),
            data.get('responsibilities[]', [])
        )
    ]
    form_data['projects'] = [
        {'title': title, 'description': description}
        for title, description in zip(
            data.get('project-title[]', []),
            data.get('project-description[]', [])
        )
    ]
    form_data['skills'] = data.get('lang', [])
    form_data['achievements'] = [
        {'title': title, 'description': description}
        for title, description in zip(
            data.get('achievement-title[]', []),
            data.get('achievement-description[]', [])
        )
    ]
    
    # Select the appropriate template
    if form_data['template'] == 'new.html':
        return render_template('new.html', data=form_data)
    elif form_data['template'] == 'new2.html':
        return render_template('new2.html', data=form_data)
    elif form_data['template'] == 'new3.html':
        return render_template('new3.html', data=form_data)
    elif form_data['template'] == 'new4.html':
        return render_template('new4.html', data=form_data)
    elif form_data['template'] == 'new5.html':
        return render_template('new5.html', data=form_data)
    elif form_data['template'] == 'new6.html':
        return render_template('new6.html', data=form_data)
    else:
        return "Invalid template selected", 400




if __name__ == '__main__':
    app.run(debug=True)
